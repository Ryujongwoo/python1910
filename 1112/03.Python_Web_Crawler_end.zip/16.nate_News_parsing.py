from urllib.request import urlopen
from bs4 import BeautifulSoup
import time

def parsing():
    url = 'https://news.nate.com/recent?mid=n0100'
    soup = BeautifulSoup(urlopen(url), 'html.parser')
    # print(soup)
    time.sleep(1)

    news_list = soup.find_all('div', class_ = 'mduSubjectList')
    # print(news_list)
    
    # 뉴스 제목
    news_title = []
    for news in news_list:
        title = news.find('strong', class_ = 'tit').get_text();
        # print(title)
        news_title.append(title)
    # print('=' * 80)

    # 뉴스 요약
    news_summary = []
    for i in range(len(news_list)):
        summary = news_list[i].find('span', class_ = 'tb').get_text();
        summary = summary[len(news_title[i]) + 1:].strip()
        # print(summary)
        news_summary.append(summary)
    # print('=' * 80)
    
    # 뉴스 링크
    news_link = []
    for i in range(len(news_list)):
        # print('https:' + news_list[i].find('a')['href'])
        news_link.append('https:' + news_list[i].find('a')['href'])
    # print('=' * 80)
    
    # 뉴스 내용
    news_content = []
    for link in news_link:
        # print(link)
        soup = BeautifulSoup(urlopen(link), 'html.parser')
        content = soup.find('div', id = 'articleContetns').find_all('table')
        
        s = ''
        for news in content:
            # print(news.get_text().strip())
            s += news.get_text().strip() + '\n'

        content = s.split('/*')
        s = content[0]
        del content
        content = s.split('\n')
        
        s = ''
        check = ['■', '☞', '▶', '▲']
        for news in content:
            if news[:1] not in check and len(news) >= 50:
                print(news)
                s += str(news)
                print('+' * 80)
        news_content.append(s)
        print('=' * 80)
    
if __name__ == '__main__':
    parsing()













