import urllib.request
from bs4 import BeautifulSoup

def searchNews():
    # 파싱할 웹 사이트의 url을 지정한다. 경기일보 메인화면 => 뉴스 메뉴
    url = "http://www.kyeonggi.com/news/articleList.html?sc_section_code=S1N2&view_type=sm"
    # 웹 사이트의 내용을 읽어온다.
    soup = BeautifulSoup(urllib.request.urlopen(url).read(), "html.parser")

    list_title = [] # 기사 제목을 저장할 빈 리스트를 선언한다.
    # 기사 제목 파싱
    for news_title in soup.find_all("div", class_="list-titles"):
        list_title.append(news_title.get_text())
    '''
    for title in list_title:
        print("%s" % title)
    print("=" * 50)
    '''

    list_summary = [] # 기사 요약을 저장할 빈 리스트를 선언한다.
    list_content = [] # 기사 내용을 저장할 빈 리스트를 선언한다.

    # 기사 요약 및 전체 기사 파싱
    for news_summary in soup.find_all("p", class_="list-summary")[:10]:
        list_summary.append(news_summary.get_text())
        for link in news_summary.find_all("a", class_="line-height-3-2x"):
            # print("http://www.kyeonggi.com" + link.get("href"))
            news_link = "http://www.kyeonggi.com" + link.get("href")
            news = BeautifulSoup(urllib.request.urlopen(news_link).read(), "html.parser")
            list_content.append(news.find("p").get_text())
    '''
    for summary in list_summary:
        print(summary)
    '''
    '''
    for content in list_content:
        print(content)
        print("=" * 50)
    '''

    print("기사 제목\n", list_title[0], "\n")
    print("기사 요약\n", list_summary[0].strip(), "\n")
    print("기사 전체\n", list_content[0])
    
if __name__ == "__main__":
    searchNews()










