# urllib.request library의 urlopen 함수를 import 한다.
from urllib.request import urlopen
from bs4 import BeautifulSoup

def parsing():
    # paesing할 url의 웹 페이지 전체 내용을 읽어온다.
    url = 'https://www.clien.net/service/group/community'
    soup = BeautifulSoup(urlopen(url).read(), 'html.parser')
    # import urllib.request와 같이 실행하면 아래와 같이 코딩해야 한다.
    # soup = BeautifulSoup(urllib.request.urlopen(url).read(), 'html.parser')
    # print(soup)
    
    list_title = [] # 파싱된 게시글의 제목을 저장할 리스트 선언
    i = 0
    for title in soup.find_all('span', class_ = 'subject_fixed'):
        i += 1
        # print('{0:2d}번 글 제목 : {1:s}'.format(i, title.get_text()))
        list_title.append(title.get_text())
    for i in range(len(list_title)):
        print(list_title[i])
    print()

    list_nickname = [] # 파싱된 게시글의 작성자를 저장할 리스트 선언
    i = 0
    for nickname in soup.find_all('span', class_ = 'nickname')[1:]:
        i += 1
        name = nickname.get_text().strip()
        if (len(name) == 0):
            name = '아이콘(' + nickname.find('img').get('alt') + ')'
            # print('{0:2d}번 글 작성자 : {1:s}'.format(i, name))
        # else:
            # print('{0:2d}번 글 작성자 : {1:s}'.format(i, name))
        list_nickname.append(name)
    for i in range(len(list_nickname)):
        print(list_nickname[i])        
    print()

    for i in range(len(list_nickname)):
        print('{0:s} : {1:s}'.format(list_nickname[i], list_title[i]))

if __name__ == '__main__':
    parsing()








