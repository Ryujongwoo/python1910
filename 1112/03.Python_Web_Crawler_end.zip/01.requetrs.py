# 특정 url의 문서 정보를 얻어오기 위해 requests 모듈을 import 한다.
import requests

#  get("url") : url로 지정된 문서의 정보를 얻어온다.
request = requests.get("http://www.dowellcomputer.com/main.jsp")

# 얻어온 정보를 얻어내는 방법
html = request.text # HTML 소스 가져오기
# header = request.headers # HTTP Header 가져오기
# status = request.status_code # HTTP Status 가져오기(200: 정상)
# is_ok = request.ok # HTTP가 정상적으로 되었는지(True/False)
print(html)
