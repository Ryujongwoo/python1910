from bs4 import BeautifulSoup
import requests

# 대화 주제를 파싱하는 함수
def get_subjects():
    # 파싱된 내용을 저장해 리턴할 빈 list를 만든다.
    subjects = []
    # 파싱할 페이지를 요청한다.
    req = requests.get("https://basicenglishspeaking.com/daily-english-conversation-topics/")
    html = req.text # 파싱할 html 코드 전체를 얻어온다.
    soup = BeautifulSoup(html, "html.parser") # 얻어온 html을 코드를 파싱할 객체를 만든다.

    # findAll() : 인수로 지정된 모든 태그를 파싱하며 반환값은 리스트이다.
    # findAll(tag, attributes)
    # tag : 파싱할 태그의 이름을 쓴다. 파싱할 태그가 여러개일 경우 list를 사용한다.
    # attributes : {"속성": "속성값"} 형태로 사용하며 특정 속성이 지정된 태그만 파싱한다.
    #              파싱할 속성의 값이 여러개일 경우 {"속성값1", "속성값2", ...} 형태로 사용한다.

    # class 속성이 su-column-inner인 모든 <div> 태그를 얻어온다.
    divs = soup.findAll("div", {"class": "su-column-inner"})
    # 파싱할 <div> 태그 개수 만큼 반복하며 파싱한다.
    for div in divs:
        # <div> 태그 내부의 모든 <a> 태그를 얻어온다.
        links = div.findAll("a")
        # 얻어온 <a> 태그의 개수 만큼 반복하며 파싱한다.
        for link in links:
            # <a> 태그 내부의 텍스트를 얻어온다.
            subject = link.text
            # 얻어온 텍스트를 list에 추가한다.
            subjects.append(subject)
    return subjects

subjects = get_subjects()
print("총", len(subjects), "개의 타입을 찾았습니다.")
for subject in subjects:
    print(subject)

