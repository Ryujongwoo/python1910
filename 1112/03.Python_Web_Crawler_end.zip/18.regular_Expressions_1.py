from urllib.request import urlopen
from bs4 import BeautifulSoup
import re

def parsing():
    url = 'http://ndb796.tistory.com/109'
    soup = BeautifulSoup(urlopen(url).read(), 'html.parser')
    texts = soup.find('div', class_='tt_article_useless_p_margin').find_all('p')

    result = []

    for i in texts:
        compile_text = re.compile('\d+')
        list = compile_text.findall(i.get_text())
        if len(list) > 0:
            result.extend(list)

    print(result)

if __name__ == "__main__":
    parsing()
