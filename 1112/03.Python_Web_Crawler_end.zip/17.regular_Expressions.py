import re

data = '''
제 번호는 010-1234-5678입니다. 전화 주세요. 017-1234-4567으로 전화해도 돼요.
그쪽 번호는 010-9999-1111 맞나요?
'''
# compile_text = re.compile(r'010-\d\d\d\d-\d\d\d\d')
compile_text = re.compile(r'010[-]\d+[-]\d+')
# compile_text = re.compile('010[-][0-9]+[-][0-9]+')
match_text = compile_text.findall(data)
print(match_text)
print('=' * 80)

p = re.compile('^[a-zA-Z0-9+_.]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$')
emails = ["gildong@gmail.com", "hello@hello", "myname@name.com",
         "abcd@.com", "abcd@abc.co.kr"]

for email in emails:
    print(email, ":", p.match(email) != None)
print('=' * 80)

p = re.compile('^[a-zA-Z0-9+-_.]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$')
emails = ['python@mail.example.com', 'python+kr@example.com',              # 올바른 형식
          'python-dojang@example.co.kr', 'python_10@example.info',         # 올바른 형식
          'python.dojang@e-xample.com',                                    # 올바른 형식
          '@example.com', 'python@example', 'python@example-com']          # 잘못된 형식
 
for email in emails:
    print(email, ' :', p.match(email) != None)
print('=' * 80)





