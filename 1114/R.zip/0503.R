# 웹 브라우저 원격 조작에 사용하는 Selenium 사용하기
# 자바스크립트 컨텐츠를 사용하는 웹 사이트의 경우 url만 안다고 해서 스크레이핑을 할 수
# 없다. => 동적 웹 사이트
# Selenium을 사용하여 자동으로 url을 랜더링해 놓고 랜더링된 결과에서 컨텐츠를 읽어와야
# 한다. 그 뿐만 아니라 컨텐츠 내에서 클릭 이벤트를 발생 시킬 수 있으며 데이터를 입력하는
# 것도 가능하다.

# Selenium 서버 기동 과정
# 1. 임의의 폴더에 selenium-server-standalone-master.zip와 chromedriver.exe를 복사한 후
#    selenium-server-standalone-master.zip의 압축을 푼다.
# 2. selenium-server-standalone-master.zip의 압축을 푼 다음 bin 폴더로 chromedriver.exe를
#    복사해 넣는다.
# 3. 윈도우 + R을 동시에 눌러 cmd 창을 띄워서 bin 폴더로 이동한다.
#    윈도우 7 또는 8인 경우 윈도우 탐색기 이용해서 bin 폴더로 이동한 후 shift 키를 누른
#    상태로 빈 화면에서 마우스 오른쪽 버튼을 클릭한다. => 여기서 명령 창 열기 클릭
# 4. cmd 프롬프트에서 java -jar selenium-server-standalone.jar -port 4445 명령을 입력해
#    Selenium 서버를 기동시킨다. => cmd 창을 닫으면 안된다.
#    Selenium Server is up and running 메시지가 보이면 정상적으로 실행중이다.

# R에서 Selenium을 사용하기 위한 패키지를 설치한다.
install.packages("RSelenium")
library(RSelenium)
# 만약에 install.packages("RSelenium")이 실행되지 않으면 아래와 같이 해야 한다.
# devtools 패키지의 install_version() 함수를 사용해서 직접 설치해야 한다.
install.packages("devtools")
library(devtools)
install_version("binman", version = "0.1.0", repos = "https://cran.uni-muenster.de/")
install_version("wdman", version = "0.2.2", repos = "https://cran.uni-muenster.de/")
install_version("RSelenium", version = "1.7.1", repos = "https://cran.uni-muenster.de/")
library(RSelenium)

# Selenium을 실행한 후 크롬을 실행한다.
# Selenium 서버에 연결한다.
remDr <- 
    remoteDriver(remoteServerAddr = "localhost", port = 4445, browserName = "chrome")
# 크롬을 실행한다.
remDr$open()
# 크롬에서 웹 사이트를 접속한다.
remDr$navigate("https://www.google.com")
# 웹 페이지에 데이터를 입력한다.
webElem <- remDr$findElement(using = "css", "[name = 'q']")
webElem$sendKeysToElement(list("JAVA", key = "enter"))

######################################################################################

# 네이버 웹툰 베스트 댓글 읽어오기
remDr <- 
    remoteDriver(remoteServerAddr = "localhost", port = 4445, browserName = "chrome")
remDr$open()
remDr$navigate("https://comic.naver.com/comment/comment.nhn?titleId=20853&no=1172")

review <- NULL # 베스트 댓글을 기억할 변수 선언
doms <- remDr$findElements(using = "css selector", "span.u_cbox_contents")
review <- sapply(doms, function(x) { x$getElementText() })
review <- unlist(review)
class(review)

######################################################################################

# 네이버 웹툰 전체 댓글 읽어오기
remDr <- 
    remoteDriver(remoteServerAddr = "localhost", port = 4445, browserName = "chrome")
remDr$open()
remDr$navigate("https://comic.naver.com/comment/comment.nhn?titleId=20853&no=1172")

# 전체 댓글을 보기 위해서 전체 댓글 링크를 얻어와 클릭한다.
reviewBtn <- remDr$findElements(using = "css selector", "#cbox_module > div > div.u_cbox_sort > div.u_cbox_sort_option > div > ul > li:nth-child(2) > a > span.u_cbox_sort_label")
sapply(reviewBtn, function(x) { x$clickElement() }) # 강제 클릭
# 대형 포털 사이트는 너무 빠르게 요청이 들어오면 공격당하는 것으로 판단할 수 있기 때문에
# sleep() 함수를 사용해 일정 시간 만큼 멈춰주는 것이 좋다.
Sys.sleep(1) # 지정된 시간 만큼 프로그램을 멈춘다. 시간 단위는 초 단위로 입력한다.

# 전체 댓글의 1페이지만 읽어온다.
review <- NULL # 전체 댓글을 기억할 변수 선언
doms <- remDr$findElements(using = "css selector", "span.u_cbox_contents")
review <- sapply(doms, function(x) { x$getElementText() })
review <- unlist(review)
#review

# 전체 댓글 페이지가 몇 페이지인지 모르기 때문에 repeat(무한 루프 => 끝이 없는 반복) 
# 명령을 이용해 무한 루프를 돌리고 끝까지 다 읽으면 무한 루프를 탈출시킨다.
#repeat {
    # 첫 페이지의 댓글은 읽어왔기 때문에 나머지 댓글을 읽어오기 위해서 9번 반복하며
    # 댓글을 읽어온다.
    # 다음 페이지 댓글을 읽어오기 위해 다음 댓글 페이지를 선택할 수 있도록 url을 만든다.
    
    # 2페이지 => #cbox_module > div > div.u_cbox_paginate > div > a:nth-child(4) > span
    # 10페이지 => #cbox_module > div > div.u_cbox_paginate > div > a:nth-child(12) > span
    
    # nth-child(n) : n번째 자식 노드(태그)를 의미한다.
    # 2페이지 부터 10페이지 까지 링크를 만들어야 하고 2페이지의 nth-child가 4이고
    # 10페이지의 nth-child가 10이므로 for를 이용해 변수 i값을 4 부터 12 까지 반복시켜
    # url을 만든다.
    for(i in 4:12) {
        nextLink <- paste("#cbox_module > div > div.u_cbox_paginate > div > a:nth-child(",
                     i, ") > span", sep = "")
        # print(nextLink)
        # 다음 페이지의 댓글을 읽어오기 위해 다음 페이지 버튼의 링크를 얻어온다.
        nextPage <- remDr$findElements(using = "css selector", nextLink)
        
        # 다음에 읽을 댓글 페이지 버튼의 링크가 없으면 댓글을 다 읽어온 것이므로
        # 무한 루프를 탈출시킨다.
        if(length(nextPage) == 0) {
            break # for 또는 repeat의 {} 블록을 탈출한다.
        }
        
        # 위 if의 조건이 만족하지 않는다면 다음에 읽을 페이지 버튼의 링크가 있는
        # 것이므로 강제 클릭한다.
        sapply(nextPage, function(x) { x$clickElement() }) # 강제 클릭
        Sys.sleep(1)
        
        # 다음 페이지의 댓글 내용을 읽어들인다.
        doms <- remDr$findElements(using = "css selector", "span.u_cbox_contents")
        result <- sapply(doms, function(x) { x$getElementText() })
        # 먼저 읽어두었던 댓글에 지금 읽은 댓글을 붙여준다.
        review <- c(review, unlist(result))
    }
#}













