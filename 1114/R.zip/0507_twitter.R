# 트위터 검색하기
install.packages("twitteR")
library(twitteR)

# 트위터 검색을 하기 위한 api key를 설정한다.
api_key <- "gjUkHgO8bFmNobRk4g0Jas8xb"
api_secret <- "loF0mtnzLhtQDFjahdRHox6wcR1fiD6Fw95DP5QCSy3rLTTP1K"
access_token <- "607145164-8L5HtzopZzhjuBCgusUGKE3MHOa9P4RbmhUrM0E1"
access_token_secret <- "2wn2bsCA7JIH5DZ5Ss1deS5BNLabzaX2xSpM2ZLMIqwQf"

# 트위터에 연결한다.
setup_twitter_oauth(api_key, api_secret, access_token, access_token_secret)
# 트위터에 연결될 때 아래 메시지를 출력하고 응답을 기다리는데 "2"를 입력한다.
# Use a local file ('.httr-oauth'), to cache OAuth access credentials between R sessions?
# 1: Yes
# 2: No
# 선택: 2

# 트위터에서 검색할 검색어를 지정한다.
key <- "취업"
# 검색어를 유니코드로 변경한다.
key <- enc2utf8(key)
# 검색어가 포함된 트위터를 지정한 개수(n) 만큼 찾는다.
result <- searchTwitter(key, since = "2017-01-01", n = 100)
result <- searchTwitter(key, since = "2017-01-01", geocode = '37.501, 127.042, 400km',
                        n = 10000)
# 검색된 내용을 데이터 프레임을 변환한다.
twitter_df <- twListToDF(result)
twitter_df$text

# 트위터에서 읽어온 내용을 워드 클라우드로 만든다.
install.packages("rJava")
install.packages("memoise")
install.packages("dplyr")
install.packages("KoNLP")
library(dplyr)
library(KoNLP)
useNIADic()
install.packages("wordcloud")
library(wordcloud)
library(RColorBrewer)
install.packages("stringr")
library(stringr)

twitter_data <- gsub("[[:lower:][:upper:][:digit:][:punct:][:cntrl:]]", "",
                     twitter_df$text)
nouns <- extractNoun(twitter_data)
nouns <- unlist(nouns)
wordCount <- table(nouns)
wordCount_df <- as.data.frame(wordCount)
wordCount_df <- rename(wordCount_df, word = nouns, freq = Freq)
wordCount_df <- wordCount_df %>% filter(nchar(word) >= 2 & nchar(word) <= 10)
top100 <- wordCount_df %>% arrange(desc(freq)) %>% head(100)

pal <- brewer.pal(8, "Dark2")
set.seed(1)
wordcloud(words = top100$word, # 워드 클라우드로 표현할 단어가 기억된 변수
          freq = top100$freq,  # 워드 클라우드로 표시할 단여별 출현 빈도수가 기억된 변수
          min.freq = 2,        # 워드 클라우드에 표시할 단어의 최소 개수
          max.words = 100,     # 워드 클라우드에 표시할 단어의 최대 개수
          random.order = F,    # 출현 빈도수가 높은 단어를 워드 클라우드 중앙에 배치한다.
          rot.per = 0.1,       # 워드 클라우드에 표시되는 단어의 회전 비율
          scale = c(4, 0.3),   # 워드 클라우드에 표시되는 단어 크기의 범위
          colors = pal         # 단어에 표시할 색상 목록
)
