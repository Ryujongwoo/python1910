# 정적 웹 스크레이핑(크롤링)
# 네이버 영화 사이트 데이터 중에서 영화 제목, 평점, 리뷰만 추출해서 csv 파일로 저장한다.
# 타겟 사이트 : https://movie.naver.com/movie/point/af/list.nhn
# 문서 구조
# 영화 제목 : class="movie"
# 영화 평점 : class="point"
# 영화 리뷰 : class="title"

# 웹 스크레이핑에 사용할 패키지를 설치하고 로드한다. < 1 >
install.packages("rvest")
library(rvest)

# 웹 스크레이핑 할 웹 사이트 주소를 저장한다.
url <- "https://movie.naver.com/movie/point/af/list.nhn?&page=1" # < 2 >
# read_html() 함수로 지정된 웹 사이트 전체 내용을 읽는다.
# encoding = "CP949" 옵션을 지정해서 한글이 깨지지 않게 한다.
html <- read_html(url, encoding = "CP949") # < 3 >

# 읽어들인 웹 사이트에서 영화 제목만 읽어온다.
# read_html() 함수로 읽어들인 html 문서에서 html_nodes() 함수로 class 속성이 movie인 태그와
# 모든 자손 태그를 읽어온다.
nodes <- html_nodes(html, ".movie") # < 4 >
# html_text() 함수로 읽어들인 class 속성이 movie인 태그에서 문자열만 얻어온다.
movie <- html_text(nodes) # < 5 >

# 읽어들인 웹 사이트에서 영화 평점만 읽어온다.
nodes <- html_nodes(html, ".point") # < 6 >
# html_text() 함수로 읽어들인 class 속성이 point인 태그에서 문자열만 얻어온다.
point <- html_text(nodes) # < 7 >

# 읽어들인 웹 사이트에서 영화 리뷰만 읽어온다.
nodes <- html_nodes(html, ".title") # < 8 >
# html_text() 함수로 읽어들인 class 속성이 title인 태그에서 문자열만 얻어온다.
# html_text() 함수로 읽을 때 불필요한 빈 칸은 trim = T 옵션을 지정해 제거한다.
title <- html_text(nodes, trim = T) # < 9 >

# csv 파일로 저장하기 전에 데이터를 정제한다. < 10 >
title <- gsub("\t", "", title)
title <- gsub("\n", "", title)
title <- gsub(" 신고", "", title)

# cbind() 함수로 영화 제목, 영화 평점, 영화 리뷰를 2개씩 합친다. < 11 >
page <- cbind(movie, point)
page <- cbind(page, title)
class(page) # matrix

# 웹 스크레이핑된 데이터를 csv 파일로 저장한다.
write.csv(page, "movie_review.csv") # < 11 >

######################################################################################

# 반복문을 사용해서 여러 페이지 스크레이핑 하기
# for(변수 in 반복횟수) {
#     반복할 문장
#     ...
# }

# i 값이 1 부터 5까지 1씩 증가하면서 {} 블록을 반복한다.
for(i in 1:5) {
    print(i)
}

# i 값이 5 부터 1까지 1씩 감소하면서 {} 블록을 반복한다.
for(i in 5:1) {
    print(i)
}

# i 값이 1, 3, 5, 7, 9로 변하면서 {} 블록을 반복한다.
for(i in c(1, 3, 5, 7, 9)) {
    print(i)
}

# i 값이 1, 3, 5, 7, 9로 변하면서 {} 블록을 반복한다.
for(i in seq(1, 10, by = 2)) {
    print(i)
}

# i 값이 10, 8, 6, 4, 2로 변하면서 {} 블록을 반복한다.
# by 옵션을 생략하면 증가치가 1이 기본값으로 사용되고 by 없이 증가치만 쓸 수 있다.
for(i in seq(10, 1, -2)) {
    print(i)
}

######################################################################################

# 웹 스크레이핑 할 때 변경되지 않는 주소를 저장해둔다.
site <- "https://movie.naver.com/movie/point/af/list.nhn?&page="
# 여러 페이지에서 읽어온 리뷰를 합칠 기억장소를 선언한다.
movie_review <- NULL # NULL => 아무것도 없다는 것을 의미한다.

# 읽어들일 페이지 개수만큼 반복하며 웹 페이지의 데이터를 읽어서 movie_review에 저장한다.
for(i in 1:100) {
    # paste() 함수를 이용해 변경되지 않는 주소와 변경되는 주소를 이어 붙여서
    # 웹 스크레이핑 할 주소를 완성한다.
    url <- paste(site, i, sep = "")
    # print(url)
    html <- read_html(url, encoding = "CP949")
    nodes <- html_nodes(html, ".movie") # < 4 >
    movie <- html_text(nodes) # < 5 >
    nodes <- html_nodes(html, ".point") # < 6 >
    point <- html_text(nodes)
    nodes <- html_nodes(html, ".title") # < 8 >
    title <- html_text(nodes, trim = T) # < 9 >
    title <- gsub("\t", "", title)
    title <- gsub("\n", "", title)
    title <- gsub(" 신고", "", title)
    page <- cbind(movie, point)
    page <- cbind(page, title)
    # rbind() 함수로 movie_review에 읽어들인 한 페이지 내용을 합쳐준다.
    movie_review <- rbind(movie_review, page)
}
print(head(movie_review, 10))
class(movie_review) # matrix
write.csv(movie_review, "movie_review.csv")

# 스크레이핑된 내용은 matrix 형태이므로 as.data.frame() 함수를 사용해서 데이터 프레임
# 형태로 변환시킨 후 사용한다.
# csv 파일을 read.csv() 함수로 읽으면 데이터 프레임으로 읽어오므로 변환시킬 필요없다.
movie_review <- as.data.frame(movie_review)
class(movie_review) # data.frame

######################################################################################

# 100 페이지 까지 읽어온 네이버 영화 리뷰의 영화별 평점 그래프 출력하기

naverMovie <- read.csv("movie_review.csv")
class(naverMovie) # data.frame

# 범주 변수(factor)는 연산할 수 없으므로 연속 변수로 변환한 후 사용해야 한다.
class(naverMovie$movie) # factor, 범주 변수
class(naverMovie$point) # integer, 연속 변수
class(naverMovie$title) # factor, 범주 변수

# 범주 변수를 연속 변수로 변환한다.
naverMovie$movie <- as.character(naverMovie$movie)
naverMovie$title <- as.character(naverMovie$title)
class(naverMovie$movie) # character, 연속 변수
class(naverMovie$title) # character, 연속 변수

# round(숫자, 반올림 후 표시 할 자리수)
# rount() 함수는 숫자를 반올림해서 반올림 후 표시 할 자리수 까지 표시한다.
# 반올림 후 표시 할 자리수
# 2 : 소수점 아래 3번째 자리에서 반올림해서 2번째 자리까지 표시한다.
# 1 : 소수점 아래 2번째 자리에서 반올림해서 1번째 자리까지 표시한다.
# 0 : 소수점 아래 1번째 자리에서 반올림해서 일의 자리까지 표시한다.
# -1 : 일의 자리에서 반올림해서 십의 자리까지 표시한다.
# -2 : 십의 자리에서 반올림해서 백의 자리까지 표시한다.

library(dplyr)
naverMovie_mean <- naverMovie %>% 
    group_by(movie) %>% 
    summarise(n = n(), mean = round(mean(point), 1)) %>% 
    filter(n >= 5) %>% 
    arrange(desc(n)) %>% 
    head(10)

library(ggplot2)
ggplot(data = naverMovie_mean, aes(x = movie, y = mean)) +
    geom_col() + 
    coord_flip() + # x축과 y축을 뒤집는다.
    ylim(0, 10) +
    ggtitle("네이버 영화 평점") + # 차트 제목
    xlab("영화제목") + # x축 레이블
    ylab("평점") + # y축 레이블
    geom_text(aes(label = n), hjust = -0.5) # 각 차트에 표시할 값













