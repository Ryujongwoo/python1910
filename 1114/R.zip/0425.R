df_na <- data.frame(gender = c("M", "F", NA, "F", "M"), score = c(5, 4, 3, 2, NA))
is.na(df_na)
table(is.na(df_na))
table(is.na(df_na$gender))
table(is.na(df_na$score))
sum(df_na$score)
mean(df_na$score)

library(dplyr)
df_no_na <- df_na %>% filter(!is.na(score)) # score에서 NA 제거
sum(df_no_na$score)
mean(df_no_na$score)
df_no_na <- df_no_na %>% filter(!is.na(gender)) # gender에서 NA 제거

# score가 NA가 아니고 gender도 NA가 아닌 데이터만 추출한다.
df_no_na2 <- df_na %>% filter(!is.na(score) & !is.na(gender))

# na.omit() 함수를 이용해 결측치가 있는 모든 행을 한꺼번에 제거할 수 있다.
df_no_na3 <- na.omit(df_na)

# 함수를 실행할 때 na.rm = T 속성을 지정하면 결측치를 제외하고 함수를 실행한다.
sum(df_na$score, na.rm = T)
mean(df_na$score, na.rm = T)
max(df_na$score, na.rm = T)
min(df_na$score, na.rm = T)
length(df_na$score) # length() 함수에는 na.rm = T를 사용할 수 없다.

######################################################################################

csv_exam <- read.csv("csv_exam.csv")
csv_exam_na <- csv_exam

# 3, 8, 15행 math열과 20행 science 열을 NA로 만든다.
csv_exam_na[c(3, 8, 15), "math"] <- NA
csv_exam_na[20, "science"] <- NA
table(is.na(csv_exam_na))

# na.rm = T는 dplyr 패키지의 summarise() 함수에서 사용하는 그룹 함수에도 사용이
# 가능하다.
# summarise() 함수의 그룹 함수 중에서 n() 함수에는 na.rm = T를 사용할 수 없다.
# n(), length() 함수는 결측치도 데이터에 포함시켜서 개수를 센다.
csv_exam_na %>% 
    group_by(class) %>% 
    summarise(
        sum_math = sum(math, na.rm = T),
        mean_math = mean(math, na.rm = T),
        median_math = median(math, na.rm = T),
        n_math = n(),
        n_length = length(math),
    )
# summarise() 함수를 사용하지 않고 데이터의 개수만 계산하려 하는 경우 tally() 함수를
# 사용해도 된다.
tally(csv_exam_na)

# 결측치의 개수를 세지 않으려면 filter() 함수로 결측치를 걸러내고 개수를 세면된다.
csv_exam_na %>% 
    filter(!is.na(math)) %>% 
    group_by(class) %>% 
    summarise(
        sum_math = sum(math),
        mean_math = mean(math),
        median_math = median(math),
        n_math = n(),
        n_length = length(math),
    )

# filter() 함수가 갑자기 기억이 안나면 원본 데이터에 na.omit() 함수를 적용시켜서
# 파이프(%>%)로 함수에 넘겨주면 된다.
na.omit(csv_exam_na) %>% 
    group_by(class) %>% 
    summarise(
        sum_math = sum(math),
        mean_math = mean(math),
        median_math = median(math),
        n_math = n(),
        n_length = length(math),
    )

# ifelse() 함수를 사용해서 결측치를 결측치가 아닌 다른 값으로 대체한다. => 평균, 중위수
mean(csv_exam_na$math, na.rm = T) # 55
mean(csv_exam_na$science, na.rm = T) # 60
# math의 3, 8, 15 번째 데이터를 NA에서 55로 대체하고 science의 20 번째 데이터를
# NA에서 60으로 대체한다.
csv_exam_na$math <- 
    ifelse(is.na(csv_exam_na$math), mean(csv_exam_na$math, na.rm = T), csv_exam_na$math)
csv_exam_na$science <- 
    ifelse(is.na(csv_exam_na$science), mean(csv_exam_na$science, na.rm = T), 
           csv_exam_na$science)

#######################################################################################

# 이상한 데이터 : 이상치, 극단치, outlier
# 이상한 데이터는 존재할 수 없는 값이 데이터에 포함되어 있음을 의미한다.
# 발견된 이상한 데이터는 결측치로 변환한 후 제거하거나 다른 값으로 대체해 사용한다.

# gender는 1과 2만 가질 수 있고 score는 1 ~ 5만 가질 수 있다.
outlier <- data.frame(gender = c(1, 2, 1, 3, 1, 2), score = c(5, 4, 3, 2, 5, 6))
table(outlier)
table(outlier$gender)
table(outlier$score)
# 이상치가 있는 경우 ifelse() 함수를 이용해 이상치를 결측치로 변환한다.
outlier$gender <- ifelse(outlier$gender > 2, NA, outlier$gender)
outlier$score <- ifelse(outlier$score > 5, NA, outlier$score)
table(outlier$gender)
table(outlier$score)

library(ggplot2)
# boxplot() 함수의 실행 결과를 참고해서 
# ggplot2 패키지에서 제공되는 샘플 데이터가 손상된 경우 아래와 같이 실행하면 복구된다.
mpg <- ggplot2::mpg
mpg_copy <- mpg

# ggplot2 패키지가 제공하는 mpg라는 데이터프레임에의 hwy 변수 데이터 중에서 극단치를
# 결측치로 변환한다.
table(mpg_copy$hwy)
boxplot(mpg_copy$hwy)
boxplot(mpg_copy$hwy)$stats
#      [,1]
# [1,]   12 # 최저
# [2,]   18 # 1사분위수
# [3,]   24 # 평균
# [4,]   27 # 3사분위수
# [5,]   37 # 최고
# boxplot(mpg$hwy)$stats 실행 결과 12 미만이거나 37을 초과하는 경우 극단치로 처리한다.
mpg_copy$hwy <- ifelse(mpg_copy$hwy < 12 | mpg_copy$hwy > 37, NA, mpg_copy$hwy)

#######################################################################################

# ggplot2 패키지를 이용해 그래프 만들기
# ggplot2 그래프는 레이어 구조로 되어있다. => 3층 레이어를 사용한다.
# 1층 => 배경, 2층 => 그래프, 3층 이상 => 그래프 꾸미기(축, 색, 표식 등)

# 산점도 : 연속된 값으로 되어있는 두 변수간의 관계를 표현한다.
# 그래프가 출력될 배경을 만든다.
# ggplot(data = 데이터프레임, aes(x = x(가로)축, y = y(세로)축))
ggplot(data = mpg, aes(x = displ, y = hwy))
# 배경에 geom_그래프이름() 함수로 배경에 "+"로 연결해서 그래프를 추가한다.
ggplot(data = mpg, aes(x = displ, y = hwy)) + geom_point()
ggplot(data = mpg, aes(x = displ, y = cty)) + geom_point()
ggplot(data = mpg, aes(x = hwy, y = cty)) + geom_point()
# 완성된 그래프에 축, 색, 표식을 추가한다.
# xlim() ylim()
ggplot(data = mpg, aes(x = displ, y = hwy)) + 
    geom_point() + 
    xlim(3, 6) +
    ylim(15, 30)
    
# 막대 그래프 : 데이터의 크기를 막대로 표시한다.
# 구동 방식별 고속도로 연비 평균
mpg_drv <- mpg %>% 
    group_by(drv) %>% 
    summarise(mean_hwy = mean(hwy))
ggplot(data = mpg_drv, aes(x = drv, y = mean_hwy)) +
    geom_col()

# 차종별 도시 연비 평균
mpg_class <- mpg %>% 
    group_by(class) %>% 
    summarise(mean_cty = mean(cty))
ggplot(mpg_class, aes(class, mean_cty)) + 
    geom_col()

# reorder() 함수를 이용해 x축 항목의 정렬 순서를 변경할 수 있다.
# reorder(class, mean_cty) : 차종을 mean_cty의 오름차순으로 정렬한다.
ggplot(mpg_class, aes(reorder(class, mean_cty), mean_cty)) + 
    geom_col()
# reorder() 함수로 정렬할 때 2번째 인수 앞에 "-"를 붙이면 내림차순으로 정렬된다.
ggplot(mpg_class, aes(reorder(class, -mean_cty), mean_cty)) + 
    geom_col()

# 어떤 회사에서 생산한 suv 자동차가 연비가 높은지 알아보기 위해 suv 차종을 대상으로
# 도시 연비 평균이 가장 높은 다섯곳을 나타내는 막대 그래프를 연비가 높은 순서로
# 정렬해서 만든다.
mpg_suv <- mpg %>% 
    filter(class == "suv") %>% 
    group_by(manufacturer) %>% 
    summarise(mean_cty = mean(cty)) %>% 
    arrange(desc(mean_cty)) %>% 
    head(5)
ggplot(mpg_suv, aes(manufacturer, mean_cty)) +
    geom_col()
ggplot(mpg_suv, aes(reorder(manufacturer, mean_cty), mean_cty)) +
    geom_col()
ggplot(mpg_suv, aes(reorder(manufacturer, -mean_cty), mean_cty)) +
    geom_col()

# 빈도(개수) 막대 그래프 : x축만 지정하고 y축은 지정하지 않는다.
ggplot(data = mpg, aes(x = drv)) + geom_bar()
ggplot(data = mpg, aes(x = class)) + geom_bar()

# geom_col()는 원래 데이터를 가공해서 요약한 평균 데이터를 이용해 그래프를 만든다.
# geom_bar()는 원래 데이터를 가공하지 않고 개수만 가지고 그래프를 만든다.

# 선 그래프
economics
ggplot(data = economics, aes(x = date, y = unemploy)) + geom_line() # 실업자 수
ggplot(data = economics, aes(x = date, y = psavert)) + geom_line() # 저축율
ggplot(data = economics, aes(x = date, y = uempmed)) + geom_line() # 실업율
ggplot(data = economics, aes(x = date, y = pce)) + geom_line() # 개인 소비 지출
# 200줄 채움



