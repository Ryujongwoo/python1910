# 외부 파일 불러오기
# read.csv() 함수를 이용해서 csv 파일(데이터가 ","로 구분된 파일)을
# data frame으로 읽어온다.
df_csv_exam <- read.csv("csv_exam.csv")
class(df_csv_exam)

df_csv_exam # data frame 전체를 출력한다.
df_csv_exam[] # []만 적으면 df_csv_exam을 실행한 결과와 같은 결과가 출력된다.
df_csv_exam[1,] # data frame의 1행만 출력한다.
df_csv_exam[1:2,] # data frame의 1행 부터 2행까지 출력한다.
df_csv_exam[c(1, 3),] # data frame의 1행과 3행을 출력한다.

# data frame을 열단위로 추출할 때 [열], ["열이름"] 형식으로 추출하면 추출된 데이터는
# data frame 형태로 추출된다.
df_csv_exam[3] # data frame의 3(math)열을 출력한다.
class(df_csv_exam[3]) # data.frame
df_csv_exam["math"]
class(df_csv_exam["math"]) # data.frame

df_csv_exam[,3]
class(df_csv_exam[,3]) # integer
df_csv_exam[,"math"]
class(df_csv_exam[,"math"]) # integer
df_csv_exam$math
class(df_csv_exam$math) # integer

# class, math 열을 data frame 형태로 얻어온다.
df_csv_exam[2:3]
df_csv_exam[c("class", "math")]
#class science 열을 data frame 형태로 얻어온다.
df_csv_exam[c(2, 5)]
df_csv_exam[c("class", "science")]

# 조건을 만족하는 data frame의 데이터 출력하기
# 관계 연산자 : 조건을 비교한다. 결과는 참(TRUE, T) 또는 거짓(FALSE, F)만 나온다.
# >(크다, 초과), >=(크거나 같다, 이상), <(작다, 미만), <=(작거나 같다, 이하)
# ==(같다), !=(같지 않다)

# data frame에서 class열에 저장된 값이 1인 행만 출력한다.
df_csv_exam[df_csv_exam$class == 1,] # 행만 출력해야 하므로 ","를 빼먹으면 안된다.
# data frame에서 class열에 저장된 값이 2인 행만 출력한다.
df_csv_exam[df_csv_exam$class == 2,]

# 논리 연산자 : 두 개의 논리값(조건)을 비교한다. 결과는 참 또는 거짓만 나온다.
# &(and, 논리곱) : 두 개의 조건이 모두 참일 경우만 참, ~이고, ~이면서, ~중에서
# |(or, 논리합) : 두 개의 조건중 한 개 이상 참일 경우에 참, ~또는, ~이거나

# data frame에서 class열에 저장된 값이 1과 2인인 행만 출력한다.
df_csv_exam[df_csv_exam$class == 1 | df_csv_exam$class == 2,]
df_csv_exam[df_csv_exam$class >= 1 & df_csv_exam$class <= 2,]
# data frame에서 class열에 저장된 값이 1과 3인인 행만 출력한다.
df_csv_exam[df_csv_exam$class == 1 | df_csv_exam$class == 3,]

# data frame에서 class열에 저장된 값이 3이고 english 점수가 90 이상인 행만 출력한다.
df_csv_exam[df_csv_exam$class == 3 & df_csv_exam$english >= 90,]

# read.csv() 함수의 header 옵션을 사용하면 csv 파일의 첫 줄을 열 이름이 아닌
# 데이터로 처리할 수 있다.
# header의 생략시 기본값은 True이고 False를 쓰면 첫 줄을 데이터로 취급한다.
# csv 파일의 첫 줄이 열 이름이 아닐 경우 header 옵션을 FALSE를 지정해서 읽어온 후
# 열 이름을 변경시키면 된다.
df_csv_exam_noheader <- read.csv("csv_exam_noheader.csv", header = FALSE)
# 원본을 가지고 작업하다 망칠것에 대비하기 위해 사본을 만들어 작업하는것이 좋다.
df_csv_exam_copy <- df_csv_exam_noheader

# data frame의 열 이름을 변경하려면 dplyr 패키지의 rename() 함수를 사용한다.
# rename() 함수를 사용하기 위해 dplyr 패키지를 설치하고 로드시킨다.
install.packages("dplyr")
library(dplyr)
# rename(data frame, 새변수명 = 기존변수명, ...)
df_csv_exam_copy <- rename(df_csv_exam_copy, id = V1)
df_csv_exam_copy <- rename(df_csv_exam_copy, class = V2, math = V3, english = V4,
                           science = V5)

# readxl 패키지의 read_excel() 함수를 사용하면 excel 파일을 csv 형태로
# 변환하지 않고 읽어올 수 있다.
install.packages("readxl")
library(readxl)
df_excel_exam <- as.data.frame(read_excel("excel_exam.xlsx"))
class(df_excel_exam)

# read_excel() 함수로 읽어들인 excel 파일이 열 이름이 없는 경우 R이 자동으로 ...1과
# 같이 자동으로 데이터 첫 줄을 열 이름으로 만든다.
# excel 파일의 첫 줄이 열 이름이 아니면 col_names = F 옵션을 지정해서 읽어들인다.
# 읽어들인 후 열 이름을 별도로 지정하면 된다.
df_excel_exam_noheader <- as.data.frame(read_excel("excel_exam_noheader.xlsx",
                                                   col_names = F))
df_excel_exam_copy <- df_excel_exam_noheader
# read_excel() 함수가 자동으로 붙여준 열 이름 ...1이 에러가 발생되면 따옴표로
# 묶어서 사용한다.
df_excel_exam_copy <- rename(df_excel_exam_copy, id = "...1")
df_excel_exam_copy <- rename(df_excel_exam_copy, class = "...2", math = "...3",
                            english = "...4", science = "...5")

# 읽어들일 excel 파일에 여러개의 sheet가 있을 때 특정 시트의 데이터를 읽으려면
# sheet 옵션을 사용해서 읽을 시트를 지정하면 된다.
# sheet 옵션을 지정하지 않으면 기본값으로 1번째 sheet를 읽어온다.
df_excel_exam <- as.data.frame(read_excel("excel_exam.xlsx", sheet = 2))

###################################################################################

# write.csv() 함수로 data frame을 csv 파일로 저장한다.
# write.csv(data frame, file = "파일명.csv")
# write.csv() 함수를 실행할 때 "Permission denied" 메시지가 출력되는 이유는
# 저장하려는 이름의 파일이 열려있기 때문이다.
# data frame을 csv 파일로 저장시키면 기본적으로 행 번호도 같이 csv 파일에 저장된다.
write.csv(df_excel_exam, file = "df_excel_exam.csv")
# csv 파일로 저장할 때 행 번호를 저장하지 않으려면 row.names = F 옵션을 지정한다.
write.csv(df_excel_exam, file = "df_excel_exam.csv", row.names = F)

##################################################################################

# RData 파일은 R 전용 데이터 파일로 다른 파일에 비해서 R에서 읽고 쓰는 속도가 
# 빠르고 용량이 작은 장점이 있는 파일이다.
# 일반적으로 R에서 작업을 할 때는 RData 파일을 사용하고 R을 사용하지 않는 사람과
# 데이터를 주고 받을 경우 csv 파일이나 excel 파일을 사용한다.
# 작업중인 데이터를 R 전용 데이터 파일로 저장하고 필요할 때 불러와서 사용한다.

# save() 함수로 작업중인 data frame을 RData 파일로 저장한다.
# save(data frame, file = "파일명.rda")
save(df_excel_exam, file = "df_excel_exam.rda")

# rm() 함수로 사용중인 변수를 메모리에서 삭제할 수 있다.
rm(df_excel_exam)

# load() 함수로 RData 파일의 내용을 메모리로 불러온다.
# load(file = "파일명.rda")
load(file = "df_excel_exam.rda")
# load() 함수로 읽어온 RData 파일을 변수에 할당하면 문자 데이터로 인식된다.
df_excel_exam_rda <- load(file = "df_excel_exam.rda")








