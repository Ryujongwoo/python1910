# 파생(계산에 의한) 변수 만들기
# 파생 변수란 원래 데이터를 가공해서 만든 변수(열)를 말한다.
# 데이터프레임$파생변수명 <- 파생 변수에 대입할 데이터
df_raw <- data.frame(var1 = c(1, 2, 3), var2 = c(2, 3, 4))
df_var <- df_raw
df_var$var_sum <- df_var$var1 + df_var$var2
df_var$var_mean <- (df_var$var1 + df_var$var2) / 2
df_var$var_mean1 <- df_var$var_sum / 2

df_csv_exam <- read.csv("csv_exam.csv")
df_csv_copy <- df_csv_exam
df_csv_copy$total <- df_csv_copy$math + df_csv_copy$english + df_csv_copy$science
df_csv_copy$mean <- df_csv_copy$total / 3

# subset() : 데이터프레임에서 특정 변수(열)의 데이터만 뽑아낼 수 있다.
# subset(데이터프레임, select = 시작변수명:끝변수명)
df_csv_copy[c("math", "english", "science")]
subset(df_csv_copy, select = math:science)
# rowSums() : 행의 합계를 계산한다.
df_csv_copy$total1 <- rowSums(subset(df_csv_copy, select = math:science))
# rowMeans() : 행의 평균을 계산한다.
df_csv_copy$mean1 <- rowMeans(subset(df_csv_copy, select = math:science))

# transform() 함수를 사용해서 파생 변수를 추가할 수 있다.
# transform(데이터프레임, 파생변수명 = 파생 변수에 대입할 데이터)
df_csv_copy <- transform(df_csv_copy, total2 = 
                             rowSums(subset(df_csv_copy, select = math:science)))
df_csv_copy <- transform(df_csv_copy, mean2 = 
                             rowMeans(subset(df_csv_copy, select = math:science)))

# dplyr 라이브러리의 mutate() 함수를 사용하면 한 번에 여러개의 파생 변수를 추가할
# 수 있다.
install.packages("dplyr")
library(dplyr)
# dplyr 라이브러리는 이전 기능의 실행 결과를 다음 기능의 입력으로 넘겨주기 위해
# %>%(파이프)를 사용한다. => ctrl + shift + M을 동시에 누르면 입력된다.

# mutate(파생변수명 = 파생 변수에 대입할 데이터, ...)
df_csv_copy <- df_csv_copy %>% 
    mutate(total3 = rowSums(subset(df_csv_copy, select = math:science)), 
           mean3 = rowMeans(subset(df_csv_copy, select = math:science))
    )

df_csv_copy1 <- df_csv_exam
# ifelse() 함수로 조건을 사용해서 파생 변수 만들기
# ifelse(조건식, 조건이 참일 경우 실행할 내용, 조건이 거짓일 경우 실행할 내용)

# 3과목의 평균 점수가 70점 이상이면 pass, 그렇치 않으면 fail이 저장되는
# result라는 파생 변수를 만든다.
df_csv_copy1 <- df_csv_copy1 %>% 
    mutate(total = rowSums(subset(df_csv_copy1, select = math:science)), 
           mean = rowMeans(subset(df_csv_copy1, select = math:science)),
    )
df_csv_copy1$result <- ifelse(df_csv_copy1$mean >= 70, "pass", "fail")

# 3과목의 평균 점수가 80점 이상이면 A, 80점 미만이고 60점 이상이면 B, 60점 
# 미만이면 C가 저장되는 grade라는 파생 변수를 만든다.
df_csv_copy1$grade <- ifelse(df_csv_copy1$mean >= 80, "A", 
                      ifelse(df_csv_copy1$mean >= 60, "B", "C"))

# 3과목의 평균 점수가 90점 이상이면 A, 80점 이상이면 B, 70점 이상이면 C,
# 60점 이상이면 D, 그렇치 않으면 F
df_csv_copy1$hakjum <- ifelse(df_csv_copy1$mean >= 90, "A", 
                       ifelse(df_csv_copy1$mean >= 80, "B",
                       ifelse(df_csv_copy1$mean >= 70, "C", 
                       ifelse(df_csv_copy1$mean >= 60, "D", "F"))))
                       
##############################################################################

# summary() 함수를 이용해서 데이터의 요약 통계량을 출력한다.
summary(df_csv_exam)
# str() 함수는 데이터프레임에 저장된 데이터의 개수, 변수(열)의 개수
# 변수 이름, 변수의 자료형, 변수에 저장된 데이터의 일부를 보여준다.
str(df_csv_exam)
# head() 함수를 이용해서 앞부분 데이터 일부를 출력한다.
head(df_csv_exam) # 개수를 생략하면 6개가 기본값이다.
head(df_csv_exam, 5) # 개수가 지정되면 지정된 개수 만큼 출력한다.
# tail() 함수를 이용해서 뒷부분 데이터 일부를 출력한다.
tail(df_csv_exam)
tail(df_csv_exam, 3)
# table() 함수를 이용해서 변수에 저장된 데이터의 빈도수를 출력한다.
table(df_csv_copy1$grade)
# hist() 함수를 이용해서 숫자 데이터의 히스토그램을 출력한다.
hist(df_csv_copy1$mean)
hist(df_csv_copy1$grade) # 문자 데이터는 히스토그램을 출력할 수 없다.

###############################################################################

# 데이터 전처리
# 데이터 전처리는 데이터를 분석 작업에 적합하도록 가공하는 작업을 말한다.
# dplyr 패키지의 함수를 이용해 데이터의 일부를 추출하거나 종류별로 나누거나
# 여러 데이터를 합치는 등의 작업을 한다.

install.packages("dplyr")
library(dplyr)
# dplyr 패키지의 주요함수
# filter() : 열 단위 추출
# select() : 행 단위 추출
# arrange() : 정렬
# mutate() : 파생 변수 추가
# summarise() : 통계치 산출
# group_by() : 그룹별로 나누기, 그룹화
# left_join() : 열 단위 데이터 합치기
# bind_rows() : 행 단위 데이터 합치기

df_csv_exam_dplyr <- df_csv_exam

# filter() 함수로 조건에 만족하는 행 단위 데이터 추출하기
df_csv_exam_dplyr[df_csv_exam_dplyr$class == 1,]
# df_csv_exam_dplyr 데이터프레임이 filter() 함수의 입력으로 사용되므로
# 변수명 앞에 데이터프레임 이름을 입력하지 않아도 자동으로 인식한다.
df_csv_exam_dplyr %>% filter(class == 1)
df_csv_exam_dplyr %>% filter(class == 1 | class == 2)
df_csv_exam_dplyr %>% filter(class == 1 | class == 2 | class == 5)
# 매칭 연산자(%in%)와 c() 함수를 사용하면 or 연산을 보다 더 쉽게 할 수 있다.
df_csv_exam_dplyr %>% filter(class %in% c(1, 2, 5))

# 함수의 연산 결과를 변수에 저장할 수 있다.
class1 <- df_csv_exam_dplyr %>% filter(class == 1)
class2 <- df_csv_exam_dplyr %>% filter(class == 2)

# manufacturer(제조회사)가 audi와 toyota 중 어떤 제조회사의 cty(도시주행연비)
# 평균이 더 높은가?
mpg_audi <- mpg %>% filter(manufacturer == "audi")
mean(mpg_audi$cty) # 17.61111
mpg_toyota <- mpg %>% filter(manufacturer == "toyota")
mean(mpg_toyota$cty) # 18.52941

# manufacturer가 chevrolet, ford, honda인 자동차의 hwy(고속도로주행연비) 전체
# 평균은 얼마인가?
mpg_manufacturer <- mpg %>% 
    filter(manufacturer %in% c("chevrolet", "ford", "honda"))
table(mpg_manufacturer$manufacturer)
mean(mpg_manufacturer$hwy) # 22.50943

