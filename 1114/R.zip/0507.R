# Selenium 서버 기동 과정
# 1. 임의의 폴더에 selenium-server-standalone-master.zip와 chromedriver.exe를 복사한 후
#    selenium-server-standalone-master.zip의 압축을 푼다.
# 2. selenium-server-standalone-master.zip의 압축을 푼 다음 bin 폴더로 chromedriver.exe를
#    복사해 넣는다.
# 3. 윈도우 + R을 동시에 눌러 cmd 창을 띄워서 bin 폴더로 이동한다.
#    윈도우 7 또는 8인 경우 윈도우 탐색기 이용해서 bin 폴더로 이동한 후 shift 키를 누른
#    상태로 빈 화면에서 마우스 오른쪽 버튼을 클릭한다. => 여기서 명령 창 열기 클릭
# 4. cmd 프롬프트에서 java -jar selenium-server-standalone.jar -port 4445 명령을 입력해
#    Selenium 서버를 기동시킨다. => cmd 창을 닫으면 안된다.
#    Selenium Server is up and running 메시지가 보이면 정상적으로 실행중이다.

# R에서 Selenium을 사용하기 위한 패키지를 설치한다.
install.packages("RSelenium")
library(RSelenium)

# Selenium 서버에 연결한다.
remDr <- remoteDriver(remoteServerAddr = "localhost", port = 4445, browserName = "chrome")
# 크롬을 실행한다.
remDr$open()
# 크롬에서 스크레이핑 할 웹 사이트를 접속한다.
remDr$navigate("https://comic.naver.com/comment/comment.nhn?titleId=20853&no=1172")

# 전체 댓글을 보기 위해서 전체 댓글 링크를 얻어와 클릭한다.
reviewBtn <- remDr$findElements(using = "css selector", "#cbox_module > div > div.u_cbox_sort > div.u_cbox_sort_option > div > ul > li:nth-child(2) > a > span.u_cbox_sort_label")
sapply(reviewBtn, function(x) { x$clickElement() }) # 강제 클릭
Sys.sleep(0.5)

# 전체 댓글의 10 페이지 중에서 1번째 페이지만 읽어온다.
review <- NULL # 전체 댓글을 기억할 변수 선언
doms <- remDr$findElements(using = "css selector", "span.u_cbox_contents")
review <- sapply(doms, function(x) { x$getElementText() })
review <- unlist(review)

repeat { # 무한 루프
    # 10 페이지 중에서 2번재 페이지 부터 10번재 페이지 까지 9번 반복하며 읽는다.
    for(i in 4:12) {
        nextLink <- paste("#cbox_module > div > div.u_cbox_paginate > div > a:nth-child(",
                          i, ") > span", sep = "")
        nextPage <- remDr$findElements(using = "css selector", nextLink)
        # 더 이상 읽을 댓글 페이지가 없으면 무한 루프를 탈출한다.
        if(length(nextPage) == 0) {
            break
        }
        sapply(nextPage, function(x) { x$clickElement() })
        Sys.sleep(0.5)
        doms <- remDr$findElements(using = "css selector", "span.u_cbox_contents")
        result <- sapply(doms, function(x) { x$getElementText() })
        review <- c(review, unlist(result))
    }
    
    # 다음 댓글 10페이지를 읽기위해 다음 10페이지 링크를 읽어온다.
    nextPage <- remDr$findElements(using = "css selector", "#cbox_module > div > div.u_cbox_paginate > div > a:nth-child(13) > span.u_cbox_cnt_page")
    # 더 이상 읽을 다음 10페이지가 없다면 무한 루프를 탈출한다.
    if(length(nextPage) == 0) {
        break
    }
    # 위의 if 조건이 만족하지 않는다면 다음에 읽을 댓글 10페이지가 있는 것이므로 강제
    # 클릭한다.
    sapply(nextPage, function(x) { x$clickElement() })
    Sys.sleep(0.5)
    
    # 새로운 10페이지로 넘어왔으므로 10 페이지 중에서 1번째 페이지만 읽어온다.
    doms <- remDr$findElements(using = "css selector", "span.u_cbox_contents")
    result <- sapply(doms, function(x) { x$getElementText() })
    review <- c(review, unlist(result))
    
}
review
class(review) # character
write.csv(review, file = "review.csv")

########################################################################################

install.packages("rJava")
install.packages("memoise")
install.packages("dplyr")
install.packages("KoNLP")
library(dplyr)
library(KoNLP)
useNIADic()

review <- read.csv("review.csv")
class(review)

# 특수 문자만 제거하고 명사를 추출한 다음 벡터로 변환시킨다.
txt <- gsub("[[:punct:]]", "", review$review)
nouns <- extractNoun(ifelse(nchar(txt) >= 130, "", txt))
nouns <- unlist(nouns)

# 단어별 빈도표를 만들고 데이터 프레임으로 변경한다.
wordCount <- table(nouns)
wordCount_df <- as.data.frame(wordCount)
wordCount_df <- rename(wordCount_df, word = nouns, freq = Freq)
head(wordCount_df)

# 불필요한 단어를 제거하고 워드 클라우드로 구현할 단어들의 출현 빈도수를 내림차순으로
# 정렬한다.
wordCount_df$word <- gsub("^[0-9]*$", "", wordCount_df$word)
wordCount_df$word <- gsub("\\W", "", wordCount_df$word)
wordCount_df$word <- gsub("ㅋㅋ", "", wordCount_df$word)
wordCount_df$word <- gsub("ㅋㅋㅋ", "", wordCount_df$word)
wordCount_df$word <- gsub("ㅋㅋㅋㅋ", "", wordCount_df$word)
wordCount_df$word <- gsub("ㅋㅋㅋㅋㅋ", "", wordCount_df$word)
wordCount_df$word <- gsub("ㅎㅎ", "", wordCount_df$word)
wordCount_df$word <- gsub("U2022", "", wordCount_df$word)
wordCount_df$word <- gsub("ㅈ같은", "", wordCount_df$word)

wordCount_df <- wordCount_df %>% filter(nchar(word) >= 2 & nchar(word) <= 10)
top100 <- wordCount_df %>% arrange(desc(freq)) %>% head(100)

# 워드 클라우드를 만든다.
install.packages("wordcloud")
library(wordcloud)
library(RColorBrewer)

pal <- brewer.pal(8, "Dark2")
set.seed(1)
wordcloud(words = top100$word, # 워드 클라우드로 표현할 단어가 기억된 변수
          freq = top100$freq,  # 워드 클라우드로 표시할 단여별 출현 빈도수가 기억된 변수
          min.freq = 2,        # 워드 클라우드에 표시할 단어의 최소 개수
          max.words = 100,     # 워드 클라우드에 표시할 단어의 최대 개수
          random.order = F,    # 출현 빈도수가 높은 단어를 워드 클라우드 중앙에 배치한다.
          rot.per = 0.1,       # 워드 클라우드에 표시되는 단어의 회전 비율
          scale = c(4, 0.3),   # 워드 클라우드에 표시되는 단어 크기의 범위
          colors = pal         # 단어에 표시할 색상 목록
)







