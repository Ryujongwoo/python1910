# 변수의 종류
# R의 변수는 연속 변수와 범주 변수로 구분할 수 있고 변수에 저장된 값이
# 똑같이 숫자라도 변수의 종류가 무엇인가에 따라서 사용할 수 있는 분석
# 방법이 달라진다.

# 연속(양적) 변수 - numeric
# 연속 변수는 키, 몸무게, 소득 같은 연속적이고 크기를 의미하는 값들로
# 구성된 변수를 의미하고, 크기를 가지기 때문에 덧셈, 뺄셈같은 산술연산이
# 가능하다.
var1 <- c(1, 2, 3, 1, 2)
class(var1) # numeric => 숫자이므로 numeric가 출력된다.
var1 + 2

# 범주(명목) 변수 - factor => factor() 함수를 사용해서 만든다.
# 범주 변수는 값이 크기가 아니고 특정한 대상을 분류하는 의미를 가지는
# 변수로 성별과 같이 남자는 1, 여자는 2로 각 범주를 분류한다.
# 숫자가 크기를 의미하지 않기 때문에 합계, 평균을 계산하는 산술연산이
# 불가능하다.
var2 <- factor(c(3, 1, 2, 3, 1, 2))
class(var2) # factor => 범주이므로 factor가 출력된다.

# 범주 변수는 크기를 의미하는 것이 아니기 때문에 문자로 구성된 변수도
# 가능하다.
var3 <- c("짜장", "짬뽕", "만두", "짜장", "짬뽕", "기스면")
class(var3) # character => 문자 변수이므로 character가 출력된다.
var4 <- factor(c("짜장", "짬뽕", "만두", "짜장", "짬뽕", "기스면"))
class(var4) # factor => 범주이므로 factor가 출력된다.
var5 <- factor(var3)
class(var5) # factor => 범주이므로 factor가 출력된다.
# 범주 변수의 Levels는 오름차순(가나다순)으로 정렬되서 출력된다.

# levels() 함수는 범주 변수의 레벨만 출력한다.
levels(var1) # NULL => var1은 연속 변수라 레벨이 없으므로 NULL이 출력된다.
levels(var2) # "1" "2" "3" => 범주 변수는 레벨이 출력된다.

mean(var1) # var1은 연속 변수이므로 평균 계산이 가능하다.
mean(var2) # var2은 범주 변수이므로 평균 계산이 불가능하다.
# as.numeric() 함수로 factor를 numeric로 변환시킬 수 있다.
var6 <- as.numeric(var2)
var7 <- as.factor(var1) # factor로 변경한다.
var8 <- as.character(var1) # character로 변경한다.

###########################################################################

# 데이터 구조, 형태 => vector, matrix, data frame, array, list
# vector : 1차원, 한 가지 타입으로 변수가 구성된다.
# matrix : 2차원, 한 가지 타입으로 변수가 구성된다.
# data frame : 2차원, 다양한 타입으로 변수가 구성된다.
# array : 다차원, matrix로 구성된다. matrix가 여러개 있는 구조이다.
# list : 다차원, data frame으로 구성된다. data frame이 여러개 있는 구조이다.

# matrix : matrix() 함수를 이용해 만든다.
var9 <- c(1:12) # vector
# matrix를 만들 때 행, 열을 지정하지 않아서 12행 1열 matrix가 생성된다.
var9 <- matrix(c(1:12))
# ncol 속성으로 matrix의 열의 개수를 지정한다.
var10 <- matrix(c(1:12), ncol = 4)
# nrow 속성으로 matrix의 행의 개수를 지정한다.
var11 <- matrix(c(1:12), nrow = 4)
var12 <- matrix(c(1:12), nrow = 2, ncol = 6)
# byrow 속성으로 행열에 데이터가 채워지는 방향을 지정할 수 있다.
# TRUE => 행우선, FALSE => 열우선, 기본값, 반드시 대문자로 입력한다.
# 다 쓰기 싫으면 TRUE를 T로 FALSE를 F로 써도 된다.
var13 <- matrix(c(1:12), nrow = 4, ncol = 3, byrow = TRUE)

# matrix 슬라이싱, 인덱싱 => []를 사용한다.
var13[4] # matrix의 지정된 위치(4)에 저장된 값 1개를 출력한다.
var13[1,] # matrix의 1행의 값을 출력한다.
var13[,1] # matrix의 1열의 값을 출력한다.
var13[3,2] # matrix의 3행 2열의 값을 출력한다.
var13[1:2] # matrix의 1번째 부터 2번째 값을 출력한다.
var13[1:2,] # matrix의 1번째 행 부터 2번째 행의 값을 출력한다.
var13[,2:3] # matrix의 2번째 열 부터 3번째 열의 값을 출력한다.
var13[c(1, 3),] # matrix의 1번째 행과 3번째 행의 값을 출력한다.
# 인덱싱, 슬라이싱 작업시 "-"를 붙여주면 제외시키는 의미가 있다.
var13[-1,] # matrix에서 1행을 제외한 값을 출력한다.
var13[-(1:2),] # matrix에서 1행 부터 2행을 제외한 값을 출력한다.
var13[-c(1, 3),] # matrix에서 1행과 3행을 제외한 값을 출력한다.

# array : array() 함수를 이용해 만든다.
# dim 속성에 c() 함수를 이용해서 행, 열, 면의 순서로 array 구조를 지정한다.
# dim = c(3, 4, 2) => 3행 4열짜리 matrix를 2개 만든다는 의미이다.
var14 <- array(c(1:24), dim = c(3, 4, 2))

# array 슬라이싱, 인덱싱 => []를 사용한다.
var14[,,1] # array의 1번째 면(matrix)을 출력한다.
var14[2,,1] # array의 1번째 면의 2번째 행을 출력한다.
var14[,3,1] # array의 1번째 면의 3번째 열을 출력한다.
var14[1,,] # array의 모든 면의 1번째 행을 출력한다.
var14[1,2,] # array의 모든 면의 1번째 행, 2번째 열을 출력한다.

# data frame : data.frame() 함수를 이용해 만든다.
# data.frame(data frame으로 만들 벡터들....)
data1 <- c(1, 2, 3, 4, 1, 2)
class(data1) # numeric
data2 <- c("a", "b", "c", "d", "a", "b")
class(data2) # character
data3 <- c(1, "a", "b", "a", 1, "c")
class(data3) # character
# data frame을 만들때 사용한 변수 이름이 data frame의 열 이름으로 사용된다.
df <- data.frame(data1, data2, data3)

# data frame의 특정 열의 값을 얻어오는 방법은 2가지 방법을 사용한다.
# 데이터프레임이름[열번호] => data frame 형태로 값을 얻어온다.
df_field1 <- df[1]
class(df_field1) # data.frame
df_field2 <- df[1:2]
class(df_field2) # data.frame
df_field3 <- df[c(1, 3)]
class(df_field3) # data.frame
# 데이터프레임이름$열이름
# 숫자 벡터는 숫자 벡터가 그대로 유지되지만 문자 벡터는 범주 변수로 변경
# 된다. => 문자 벡터를 그대로 유지하고 얻어오려면 as.character()를 사용해
# 문자 벡터로 변경시켜서 사용해야 한다.
df_field4 <- df$data1
class(df_field4) # numeric
df_field5 <- df$data2
class(df_field5) # factor
df_field6 <- as.character(df$data3)
class(df_field6) # character

# list : list() 함수를 이용해 만든다.
v <- 1
d <- data.frame(x1 = c(1, 2, 3), x2 = c("a", "b", "c"))
m <- matrix(c(1:12), ncol = 6)
a <- array(c(1:20), dim = c(2, 5, 2))
data4 <- list(list1 = v, list2 = d, list3 = m, list4 = a)
data5 <- unlist(data4)
class(data5)

#########################################################################

# 외부 파일 불러오기
# read.csv() 함수를 이용해서 csv 파일(데이터가 ","로 구분된 파일)을
# data frame으로 읽어온다.
df_csv_exam <- read.csv("csv_exam.csv")
class(df_csv_exam)

# readxl 패키지의 read_excel() 함수를 사용하면 excel 파일을 csv 형태로
# 변환하지 않고 읽어올 수 있다.
install.packages("readxl")
library(readxl)
df_excel_exam <- as.data.frame(read_excel("excel_exam.xlsx"))
class(df_excel_exam)
