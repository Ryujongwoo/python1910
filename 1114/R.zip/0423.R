install.packages("dplyr")
library(dplyr)
# dplyr 패키지의 주요함수
# filter() : 열 단위 추출
# select() : 행 단위 추출
# arrange() : 정렬
# mutate() : 파생 변수 추가
# summarise() : 통계치 산출
# group_by() : 그룹별로 나누기, 그룹화
# left_join() : 열 단위 데이터 합치기
# bind_rows() : 행 단위 데이터 합치기

df_csv_exam <- read.csv("csv_exam.csv")
df_csv_exam_dplyr <- df_csv_exam

# select() 함수로 조건에 만족하는 열(변수) 단위 데이터 추출하기
df_csv_exam_dplyr[c("math", "english", "science")]
df_csv_exam_dplyr %>% select(math, english, science)
# select() 함수의 인수로 지정하는 열 이름 앞에 "-"를 붙이면 "-"를 붙여준 변수가
# 제외된 데이터가 추출된다.
df_csv_exam_dplyr %>% select(-math, -english)

# class가 1인 math만 추출한다.
df_csv_exam_dplyr %>% filter(class == 1) %>% select(class, math)
# class가 2인 english만 추출한다.
df_csv_exam_dplyr %>% 
    select(class, english) %>% 
    filter(class == 2)
# class가 1, 3, 5인 science만 추출한다.
df_csv_exam_dplyr %>% 
    filter(class %in% c(1, 3, 5)) %>% 
    select(class, science) %>% 
    head(3)

# arrange() 함수를 사용해서 데이터를 정렬할 수 있다.
# math의 오름차순 정렬
df_csv_exam_dplyr %>% arrange(math)
# desc() 함수와 같이 사용하면 데이터를 내림차순으로 정렬할 수 있다.
df_csv_exam_dplyr %>% arrange(desc(math))
# math의 오름차순 정렬, math가 같으면 english의 오름차순 정렬, english도 같으면
# science의 내림차순 정렬
df_csv_exam_dplyr %>% arrange(math, english, desc(science))

library(ggplot2)
mpg

# audi에서 생선한 자동차 중에서 hwy가 1~5위에 해당되는 데이터를 추출한다.
mpg_audi <- mpg %>% 
    filter(manufacturer == "audi") %>% 
    arrange(desc(hwy)) %>% 
    head(5)

# mutate() 함수로 파생 변수를 추가할 수 있다.
df_csv_exam_dplyr %>% mutate(total = math + english + science)
df_csv_exam_dplyr %>% mutate(mean = (math + english + science) / 3)
df_csv_exam_dplyr %>% mutate(total = math + english + science,
                             mean = (math + english + science) / 3)
df_csv_exam_dplyr %>% 
    mutate(total = rowSums(subset(df_csv_exam_dplyr, select = math:science)), 
           mean = rowMeans(subset(df_csv_exam_dplyr, select = math:science)))

# mutate() 함수로 생성한 파생 변수를 바로 사용할 수 있다.
df_csv_exam_dplyr %>% mutate(total = math + english + science,
                             mean = total / 3)

# cty와 hwy를 더한 연비 합산 변수를 만들고 합산 연비 변수의 평균 연비 변수를
# 만든 후 평균 연비 변수가 가장 큰 자동차 데이터 3건을 추출한다.
mpg %>% 
    mutate(total = cty + hwy, mean = total / 2) %>% 
    arrange(desc(mean)) %>% 
    head(3)

# summarise() 함수와 group_by() 함수를 사용해서 그룹별로 요약하기
# mean_math라는 파생 변수를 만들고 math의 평균을 계산해서 넣어준다.
df_csv_exam_dplyr %>% mutate(mean_math = mean(math))
# 위의 식은 math의 평균을 계산해서 모든 데이터에 mean_math 이라는 파생 변수를 만들어
# 같은 값을 넣어주지만 summarise() 함수는 math의 평균만 계산한다.
# 아래의 식은 group_by() 함수로 그룹화를 하지 않아서 전체 데이터의 평균을 계산한다.
df_csv_exam_dplyr %>% summarise(mean_math = mean(math))
# group_by() 함수를 먼저 실행한 후 summarise()를 실행하면 group_by() 함수로 그룹화한
# 항목으로 묶어서 계산한다. => 반드시 그룹화를 먼저 시킨 후 summarise()를 실행한다.
# summarise(파생변수명 = 그룹함수(변수명))
df_csv_exam_dplyr %>% 
    group_by(class) %>% 
    summarise(합계 = sum(math),
              평균 = mean(math),
              중위수 = median(math),
              개수 = n(), # 괄호 안에 인수를 지정하지 않는다.
              최대값 = max(math),
              최소값 = min(math),
              분산 = var(math),
              표준편차 = sd(math)
              )

# 자동차 회사별로 그룹화, 같은 회사면 구동 방식(drv)별로 그룹화, 구동 방식도 같으면 
# 차종(class)별로 그룹화 시킨 후 도시 연비 평균을 계산한다.
mpg %>% 
    group_by(manufacturer, drv, class) %>% 
    summarise(mean_cty = mean(cty))
# 회사별로 차종이 suv인 자동차의 도시 및 고속도로 연비의 평균을 계산해 내림차순으로
# 정렬하고 상위 5개를 출력한다.
mpg %>%
    group_by(manufacturer) %>% 
    filter(class == "suv") %>% 
    mutate(average = (cty + hwy) / 2) %>% 
    summarise(mean_average = mean(average)) %>% 
    arrange(desc(mean_average)) %>% 
    head(5)

# 차종별로 도시 연비 평균을 계산해서 평균이 높은 순서로 출력한다.
mpg %>%
    group_by(class) %>% 
    summarise(mean_cty = mean(cty)) %>% 
    arrange(desc(mean_cty))

# 고속도로 연비 평균이 가장 높은 회사 3곳을 출력한다.
mpg %>%
    group_by(manufacturer) %>% 
    summarise(mean_hwy = mean(hwy)) %>% 
    arrange(desc(mean_hwy)) %>% 
    head(3)

# 각 회사별 경차(compact)의 차종 수를 내림차순으로 정렬해 출력한다.
mpg %>%
    group_by(manufacturer) %>%
    filter(class == "compact") %>% 
    summarise(count = n()) %>% 
    arrange(desc(count))

# left_join() 함수로 가로로 데이터 합치기를 할 수 있다.
# left_join(데이터프레임1, 데이터프레임2, by = 합치기의 기준이 되는 변수명)
# by 속성에는 합칠 때 기준이 되는 변수의 이름을 입력해야 하며 합쳐질 데이터에는 반드시
# 같은 이름의 변수가 있어야 한다.
# by 속성을 사용하지 않으면 두 데이터프레임에 공통으로 존재하는 열을 R이 찾아서
# 합치기를 한다. => 같은 이름의 열이 2개 이상 있으면 반드시 by 속성을 사용해야 한다.

test1 <- data.frame(id = c(1, 2, 3, 4, 5), middle = c(60, 80, 70, 90, 85))
test2 <- data.frame(id = c(1, 2, 3, 4, 5), final = c(70, 83, 65, 95, 80))
left_join(test1, test2)

# left_join() 함수는 데이터프레임에 저장된 데이터의 개수가 반드시 같아야 할 필요없다.
teacher_name <- data.frame(class = c(1, 2, 3, 4, 5), 
                teacher = c("홍길동", "임꺽정", "장길산", "일지매", "루팡"))
left_join(df_csv_exam_dplyr, teacher_name, by = "class")

# bind_rows() 함수로 세로로 합치기를 할 수 있다.
# bind_rows(데이터프레임1, 데이터프레임2)
group_a <- data.frame(id = c(1, 2, 3, 4, 5), test = c(60, 80, 70, 90, 85))
group_b <- data.frame(id = c(6, 7, 8, 9, 10), test = c(70, 83, 65, 95, 80))
bind_rows(group_a, group_b)

################################################################################

# 데이터 정제
# 데이터 정제는 빠진 데이터나 이상한 데이터를 제거하는 작업을 말한다.
# 빠진 데이터 : 결측치, NA, <NA>
# NA는 따옴표로 묶으면 안된다. => 따옴표로 묶으면 결측치를 의미하는 것이 아니고 문자열
# "NA"로 취급된다.
# 문자열 결측치는 <NA>로 표시되고 나머지 데이터의 결측치는 NA로 표시된다.
df_na <- data.frame(gender = c("M", "F", NA, "F", "M"), score = c(5, 4, 3, 2, NA))

# is.na() 함수로 데이터에 결측치가 포함되어 있나 확인할 수 있다.
# 결측치는 TRUE, 결측치가 아니면 FALSE로 표시된다.
is.na(df_na)
# is.na() 함수와 table() 함수를 이용해 결측치의 빈도수를 파악할 수 있다.
table(is.na(df_na))
table(is.na(df_na$gender))
table(is.na(df_na$score))

# 결측치가 포함된 데이터를 함수에 적용시키면 정상적인 연산이 실행되지 않고 NA가 
# 출력된다. => 정상적인 연산을 하려면 반드시 결측치를 제외시켜야 한다.
sum(df_na$score)
mean(df_na$score)

# dplyr 패키지의 filter() 함수를 이용해 결측치가 아닌 데이터만 추출한다.
# df_na 데이터프레임에서 결측치가 아닌 데이터만 추출한다.
df_no_na <- df_na %>% filter(!is.na(score))
sum(df_no_na$score)
mean(df_no_na$score)